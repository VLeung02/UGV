import RPi.GPIO as GPIO          
from time import sleep

in1poshook1 = 21 #positive for hookleftfront one
in2neghook1 = 23 #negative for hookleftfront one
in1poshook2 = 11 #positive for hookleftback two
in2neghook2 = 12 #negative for hookleftback two
in1poshook3 = 31 #positive for hookrightfront three
in2neghook3 = 33 #negative for hookrightfront three
in1poshook4 = 5 #positive for hookrightback four
in2neghook4 = 3 #negative for hookrightback four
#in1posdrive1 = 24 #postive for driveleft
#in2negdrive1 = 26  #negative for driveleft
#in1posdrive2 = 5 #postive for driveright
#in2negdrive2 = 15 #negative for driveright
enhook1 = 19 #pair hook one
enhook2 = 32 #pair hook two
enhook3 = 29 #pair hook three
enhook4 = 7 #pair hook four
#endrive1 = 22
#endrive2 = 3  #pair drive
temp1=1

GPIO.setmode(GPIO.BOARD)
GPIO.setup(in1poshook1,GPIO.OUT)
GPIO.setup(in2neghook1,GPIO.OUT)
GPIO.setup(in1poshook2,GPIO.OUT)
GPIO.setup(in2neghook2,GPIO.OUT)
GPIO.setup(in1poshook3,GPIO.OUT)
GPIO.setup(in2neghook3,GPIO.OUT)
GPIO.setup(in1poshook4,GPIO.OUT)
GPIO.setup(in2neghook4,GPIO.OUT)
#GPIO.setup(in1posdrive1,GPIO.OUT)
#GPIO.setup(in2negdrive1,GPIO.OUT)
#GPIO.setup(in1posdrive2,GPIO.OUT)
#GPIO.setup(in2negdrive2,GPIO.OUT)
GPIO.setup(enhook1,GPIO.OUT)
GPIO.setup(enhook2,GPIO.OUT)
GPIO.setup(enhook3,GPIO.OUT)
GPIO.setup(enhook4,GPIO.OUT)
#GPIO.setup(endrive1,GPIO.OUT)
#GPIO.setup(endrive2,GPIO.OUT)
GPIO.output(in1poshook1,GPIO.LOW)
GPIO.output(in2neghook1,GPIO.LOW)
GPIO.output(in1poshook2,GPIO.LOW)
GPIO.output(in2neghook2,GPIO.LOW)
GPIO.output(in1poshook3,GPIO.LOW)
GPIO.output(in2neghook3,GPIO.LOW)
GPIO.output(in1poshook4,GPIO.LOW)
GPIO.output(in2neghook4,GPIO.LOW)
#GPIO.output(in1posdrive1,GPIO.LOW)
#GPIO.output(in2negdrive1,GPIO.LOW)
#GPIO.output(in1posdrive2,GPIO.LOW)
#GPIO.output(in2negdrive2,GPIO.LOW)
GPIO.output(enhook1,GPIO.LOW)
GPIO.output(enhook2,GPIO.LOW)
GPIO.output(enhook3,GPIO.LOW)
GPIO.output(enhook4,GPIO.LOW)
#GPIO.output(endrive1,GPIO.LOW)
#GPIO.output(endrive2,GPIO.LOW)
p1=GPIO.PWM(enhook1,1000)
p2=GPIO.PWM(enhook2,1000)
p3=GPIO.PWM(enhook3,1000)
p4=GPIO.PWM(enhook4,1000)
#p5=GPIO.PWM(endrive1,1000)
#p6=GPIO.PWM(endrive2,1000)
p1.start(22)
p2.start(3) 
p3.start(11) 
p4.start(19) 
#p5.start(29) 
#p6.start(36)   #initialize GPIO.BCM pin for speed change
print("\n")
print("Adanac PD will find you")
print("Mr.Mainframe has connected")
print("The two left hooks and two right hooks work in separated pairs")
print("The drive wheels work in a pair")
print("The default speed is at 25%")
print("***DRIVE CONTROLS***")
print("R-run C-stop W-forward S-backward L-low M-medium H-high E-exit")
print("***STAIR CLIMB CONTROLS***")
print("F-left pairforward H-right pairforward T-stop stair climbing")
print("***SPEED CHANGE IS UNIVERSAL***")
print("\n")    


while(1):

    x=raw_input()
    
    if x=='r':
        print("run")
        if(temp1==1):
    	    GPIO.output(in1poshook1,GPIO.HIGH)
            GPIO.output(in2neghook1,GPIO.LOW)
            GPIO.output(in1poshook2,GPIO.LOW)
            GPIO.output(in2neghook2,GPIO.HIGH)
    	    GPIO.output(in1poshook3,GPIO.LOW)
            GPIO.output(in2neghook3,GPIO.HIGH)
            GPIO.output(in1poshook4,GPIO.HIGH)
            GPIO.output(in2neghook4,GPIO.LOW)
        print("drive flat forward")
        x='z'

    elif x=='c':
        print("stop")
        GPIO.output(in1poshook1,GPIO.LOW)
        GPIO.output(in2neghook1,GPIO.LOW)
        GPIO.output(in1poshook2,GPIO.LOW)
        GPIO.output(in2neghook2,GPIO.LOW)
        GPIO.output(in1poshook3,GPIO.LOW)
        GPIO.output(in2neghook3,GPIO.LOW)
        GPIO.output(in1poshook4,GPIO.LOW)
        GPIO.output(in2neghook4,GPIO.LOW)
        x='z'

    elif x=='w':
        print("forward")
    	GPIO.output(in1poshook1,GPIO.HIGH)
        GPIO.output(in2neghook1,GPIO.LOW)
        GPIO.output(in1poshook2,GPIO.LOW)
        GPIO.output(in2neghook2,GPIO.HIGH)
    	GPIO.output(in1poshook3,GPIO.LOW)
        GPIO.output(in2neghook3,GPIO.HIGH)
        GPIO.output(in1poshook4,GPIO.HIGH)
        GPIO.output(in2neghook4,GPIO.LOW)
        temp1=1
        x='z'

    elif x=='s':
        print("backward")
    	GPIO.output(in1poshook1,GPIO.LOW)
        GPIO.output(in2neghook1,GPIO.HIGH)
        GPIO.output(in1poshook2,GPIO.HIGH)
        GPIO.output(in2neghook2,GPIO.LOW)
    	GPIO.output(in1poshook3,GPIO.HIGH)
        GPIO.output(in2neghook3,GPIO.LOW)
        GPIO.output(in1poshook4,GPIO.LOW)
        GPIO.output(in2neghook4,GPIO.HIGH)
        temp1=0
        x='z'

    elif x=='d':
    	print("turn right")
    	GPIO.output(in1poshook3,GPIO.LOW)
        GPIO.output(in2neghook3,GPIO.HIGH)
        GPIO.output(in1poshook4,GPIO.HIGH)
        GPIO.output(in2neghook4,GPIO.LOW)
    	GPIO.output(in1poshook1,GPIO.LOW)
        GPIO.output(in2neghook1,GPIO.HIGH)
        GPIO.output(in1poshook2,GPIO.HIGH)
        GPIO.output(in2neghook2,GPIO.LOW)
        temp1=1
        x='z'
  
    elif x=='a':
    	print("turn left")
    	GPIO.output(in1poshook1,GPIO.HIGH)
        GPIO.output(in2neghook1,GPIO.LOW)
        GPIO.output(in1poshook2,GPIO.LOW)
        GPIO.output(in2neghook2,GPIO.HIGH)
    	GPIO.output(in1poshook3,GPIO.LOW)
        GPIO.output(in2neghook3,GPIO.HIGH)
        GPIO.output(in1poshook4,GPIO.HIGH)
        GPIO.output(in2neghook4,GPIO.LOW)
        temp1=1
        x='z'
    
    elif x=='f':
    	print("stair climb left pair")
    	GPIO.output(in1poshook1,GPIO.HIGH)
        GPIO.output(in2neghook1,GPIO.LOW)
        GPIO.output(in1poshook2,GPIO.LOW)
        GPIO.output(in2neghook2,GPIO.HIGH)
        temp1=1
        x='z'

    elif x=='h':
    	print("stair climb right pair")
    	GPIO.output(in1poshook3,GPIO.LOW)
        GPIO.output(in2neghook3,GPIO.HIGH)
        GPIO.output(in1poshook4,GPIO.HIGH)
        GPIO.output(in2neghook4,GPIO.LOW)
        temp1=1
        x='z'




    elif x=='l':
        print("low")
        p1.ChangeDutyCycle(25)
        p2.ChangeDutyCycle(25)
        p3.ChangeDutyCycle(25)
        p4.ChangeDutyCycle(25)
        #p5.ChangeDutyCycle(25)
        #p6.ChangeDutyCycle(25)
        x='z'

    elif x=='k':
        print("medium")
        p1.ChangeDutyCycle(60)
        p2.ChangeDutyCycle(60)
        p3.ChangeDutyCycle(60)
        p4.ChangeDutyCycle(60)
        #p5.ChangeDutyCycle(60)
        #p6.ChangeDutyCycle(60)
        x='z'

    elif x=='j':
        print("high")
        p1.ChangeDutyCycle(100)
        p2.ChangeDutyCycle(100)
        p3.ChangeDutyCycle(100)
        p4.ChangeDutyCycle(100)
        #p5.ChangeDutyCycle(100)
        #p6.ChangeDutyCycle(100)
        x='z'
     
    
    elif x=='e':
        GPIO.cleanup()
        break
    
    else:
        print("***WRONG KEY***")
        print("***REDEFINE OR RETRY***")
        print("***CTRL-C TO TERMINATE CONTROLS***")




