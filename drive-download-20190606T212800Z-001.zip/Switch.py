import pyrealsense2 as rs
import numpy as np
import cv2
import select
import sys, termios, tty, os, time


def getch():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
 
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch
 
def isData():
    return select.select([sys.stdin], [], [], 0) == ([sys.stdin], [], [])

# Configure depth and color streams
pipeline = rs.pipeline()
config = rs.config()
config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)

# Start streaming
pipeline.start(config)

kee = "1"

try:
    while True:

        frames = pipeline.wait_for_frames()

        if isData():
            kee = sys.stdin.read(1)

        # Stack both images horizontally
        if (kee == "1"):
            color_frame = frames.get_color_frame()
            if not color_frame:
                continue
            color_image = np.asanyarray(color_frame.get_data())
            images = color_image
        
        if (kee == "2"):
            depth_frame = frames.get_depth_frame()
            if not depth_frame:
                continue
            depth_image = np.asanyarray(depth_frame.get_data())
            depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_RAINBOW)
            images = depth_colormap

        if (kee == "3"):
            depth_frame = frames.get_depth_frame()
            if not depth_frame:
                continue
            depth_image = np.asanyarray(depth_frame.get_data())
            depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_JET)
            images = depth_colormap

        if (kee == "4"):
            depth_frame = frames.get_depth_frame()
            if not depth_frame:
                continue
            depth_image = np.asanyarray(depth_frame.get_data())
            depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_HSV)
            images = depth_colormap


   
        
        # Show images
        cv2.namedWindow('BOMB', cv2.WINDOW_AUTOSIZE)
        cv2.imshow('BOMB', images)
        cv2.waitKey(1)

finally:

    # Stop streaming
    pipeline.stop()





